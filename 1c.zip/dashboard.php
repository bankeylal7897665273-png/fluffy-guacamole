<?php
require_once 'config.php';
require_login();

$projects = fb_get("/projects");
$pageTitle = "Dashboard - VIP Shop";
$active = 'dashboard';
include 'includes/header.php';
?>
<div class="topbar">
  <div class="brand">⚡ VIP Shop</div>
  <a href="settings.php" class="avatar"><?php echo strtoupper(substr($_SESSION['email'],0,1)); ?></a>
</div>

<div class="container">
  <div class="section-title">🔥 Available Projects</div>

  <?php if (!$projects || !is_array($projects)): ?>
    <div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
      <p>No projects available right now.</p>
      <p style="font-size:13px;margin-top:6px">Check back soon!</p>
    </div>
  <?php else: ?>
    <div class="grid">
      <?php foreach ($projects as $id => $p): ?>
        <?php if (!$p) continue; ?>
        <a href="project.php?id=<?php echo urlencode($id); ?>" class="card">
          <img src="<?php echo htmlspecialchars($p['img'] ?? 'https://via.placeholder.com/300x200?text=Project'); ?>" 
               alt="<?php echo htmlspecialchars($p['name'] ?? ''); ?>" loading="lazy"
               onerror="this.src='https://via.placeholder.com/300x200?text=Image'">
          <div class="card-body">
            <div class="card-title"><?php echo htmlspecialchars($p['name'] ?? 'Untitled'); ?></div>
            <div class="card-price">
              ₹<?php echo htmlspecialchars($p['price'] ?? '0'); ?>
              <span style="font-size:11px;color:var(--text-dim);font-weight:600">View →</span>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
