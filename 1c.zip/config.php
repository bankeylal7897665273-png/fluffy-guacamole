<?php
session_start();

// ================= FIREBASE CONFIG =================
// Apna Firebase project ka config yaha daalo
$const firebaseConfig = {
            apiKey: "AIzaSyASlD4FM6lyIEzBAzPlflhlCwDc3Toh6Fo", authDomain: "earning-a9b0c.firebaseapp.com",
            databaseURL: "https://earning-a9b0c-default-rtdb.firebaseio.com", projectId: "earning-a9b0c",
            storageBucket: "earning-a9b0c.firebasestorage.app", messagingSenderId: "543786047307",
            appId: "1:543786047307:web:4d3d9382359c7383fd3ace"
        };

// Firebase Web API Key (REST Auth ke liye)
define('FIREBASE_API_KEY', $firebaseConfig['apiKey']);
define('FIREBASE_DB_URL', $firebaseConfig['databaseURL']);

// Admin email (jis email se login karke admin panel access hoga)
define('ADMIN_EMAIL', 'admin@example.com');

function fb_get($path) {
    $token = isset($_SESSION['idToken']) ? $_SESSION['idToken'] : '';
    $url = FIREBASE_DB_URL . $path . ".json?auth=" . $token;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

function fb_set($path, $data) {
    $token = isset($_SESSION['idToken']) ? $_SESSION['idToken'] : '';
    $url = FIREBASE_DB_URL . $path . ".json?auth=" . $token;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

function fb_push($path, $data) {
    $token = isset($_SESSION['idToken']) ? $_SESSION['idToken'] : '';
    $url = FIREBASE_DB_URL . $path . ".json?auth=" . $token;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

function fb_update($path, $data) {
    $token = isset($_SESSION['idToken']) ? $_SESSION['idToken'] : '';
    $url = FIREBASE_DB_URL . $path . ".json?auth=" . $token;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PATCH");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

function fb_delete($path) {
    $token = isset($_SESSION['idToken']) ? $_SESSION['idToken'] : '';
    $url = FIREBASE_DB_URL . $path . ".json?auth=" . $token;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

// Firebase Auth: Sign Up
function fb_signup($email, $password) {
    $url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" . FIREBASE_API_KEY;
    $data = ["email" => $email, "password" => $password, "returnSecureToken" => true];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

// Firebase Auth: Sign In
function fb_signin($email, $password) {
    $url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" . FIREBASE_API_KEY;
    $data = ["email" => $email, "password" => $password, "returnSecureToken" => true];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

function require_login() {
    if (!isset($_SESSION['uid'])) {
        header("Location: login.php");
        exit;
    }
}

function require_admin() {
    require_login();
    if ($_SESSION['email'] !== ADMIN_EMAIL) {
        header("Location: dashboard.php");
        exit;
    }
}
