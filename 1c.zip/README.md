# ⚡ VIP Shop - Live Shopping Web App

A complete VIP shopping platform built with normal PHP + Firebase (Realtime Database + Authentication).

## 📁 Files
- `config.php` — Firebase configuration & helper functions (EDIT THIS FIRST)
- `index.php` — Entry point, redirects to login/dashboard
- `login.php` — User login
- `register.php` — Create account (email, password, confirm password)
- `dashboard.php` — Shows all projects (from admin) as cards
- `project.php` — Project details page with Buy button
- `buy.php` — QR code + UPI amount + UTR submission
- `history.php` — User's purchase history with status (pending/success/rejected)
- `settings.php` — Theme switch (dark/light/colorful), profile, password change, stats
- `admin.php` — Admin panel (add/edit/delete projects, approve/reject requests, set UPI ID, copy project links)
- `logout.php` — Logout

## 🔧 Setup Instructions

### 1. Firebase Setup
1. Go to https://console.firebase.google.com and create a new project.
2. Enable **Authentication → Email/Password** sign-in method.
3. Enable **Realtime Database** (start in test mode, or set rules below).
4. Go to Project Settings → General → copy your Web API Key and config values.

### 2. Edit `config.php`
Replace the placeholder values in `$firebaseConfig` array with your real Firebase project values:
```php
$firebaseConfig = [
    "apiKey" => "YOUR_API_KEY",
    "databaseURL" => "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
    ...
];
define('ADMIN_EMAIL', 'admin@example.com'); // your admin login email
```

### 3. Realtime Database Rules (recommended)
```json
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
```

### 4. Create Admin Account
1. Register a normal account on `register.php` using the same email set in `ADMIN_EMAIL`.
2. Login — you'll now see the **Admin** tab in the bottom navigation.

### 5. Add Projects (Admin Panel)
1. Go to Admin → Projects tab.
2. Add project name, price, image URL, access link, and description.
3. Use the **3-dot menu** on any project to **Copy Link** — this gives a shareable URL like:
   `https://yourdomain.com/project.php?id=XXXXXXX`

### 6. Set UPI ID
Admin → Payment tab → enter your UPI ID. This generates QR codes automatically for every purchase.

## 💳 Purchase Flow
1. User browses Dashboard → clicks a project → clicks **Buy Now**.
2. QR code + amount shown → user pays via any UPI app → enters UTR/Transaction ID.
3. Request goes to Admin → Requests tab (pending).
4. Admin approves/rejects.
5. If approved, project unlocks on `project.php` with an **"Open Project"** button linking to the access link.
6. If rejected, user sees a **Help/Retry** button in History to resubmit payment.

## 🎨 Features
- Dark / Light / Colorful theme modes (Settings page)
- Smooth animations, loaders, skeleton effects
- Profile editing & password change (via Firebase Auth REST API)
- Mobile-first bottom navigation
- Admin stats: total projects, sold count, revenue, pending requests, total users

## 🌐 Hosting
Works on any **free PHP hosting** (000webhost, InfinityFree, etc.) — requires PHP with `curl` extension enabled (standard on all hosts).
