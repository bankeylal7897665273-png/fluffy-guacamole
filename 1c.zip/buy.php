<?php
require_once 'config.php';
require_login();

$id = $_GET['id'] ?? '';
if (!$id) { header("Location: dashboard.php"); exit; }

$project = fb_get("/projects/" . $id);
if (!$project) { header("Location: dashboard.php"); exit; }

$settings = fb_get("/settings");
$upi = $settings['upi_id'] ?? 'merchant@upi';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $utr = trim($_POST['utr']);
    if (empty($utr)) {
        $error = "Please enter your UTR / Transaction ID.";
    } else {
        $requestData = [
            "uid" => $_SESSION['uid'],
            "email" => $_SESSION['email'],
            "project_id" => $id,
            "project_name" => $project['name'] ?? '',
            "amount" => $project['price'] ?? 0,
            "utr" => $utr,
            "status" => "pending",
            "created_at" => date('Y-m-d H:i:s')
        ];
        $res = fb_push("/requests", $requestData);
        if (isset($res['name'])) {
            $success = "Request submitted successfully! Redirecting...";
        } else {
            $error = "Failed to submit request. Try again.";
        }
    }
}

$price = $project['price'] ?? 0;
$upiLink = "upi://pay?pa=" . urlencode($upi) . "&pn=VIPShop&am=" . urlencode($price) . "&cu=INR&tn=" . urlencode($project['name'] ?? 'Purchase');
$qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" . urlencode($upiLink);

$pageTitle = "Pay - " . htmlspecialchars($project['name'] ?? '');
include 'includes/header.php';
?>
<div class="topbar">
  <a href="project.php?id=<?php echo urlencode($id); ?>" class="icon-btn">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
  </a>
  <h1>Complete Payment</h1>
  <div style="width:40px"></div>
</div>

<div class="container">
  <?php if ($success): ?>
    <div class="success-msg fade-scroll"><?php echo $success; ?></div>
    <script>
      showToast("Request submitted! Redirecting to History...");
      setTimeout(()=> window.location.href = "history.php", 1800);
    </script>
  <?php else: ?>

  <?php if ($error): ?>
    <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>

  <div class="qr-wrap fade-scroll">
    <img src="<?php echo $qrUrl; ?>" alt="Payment QR Code">
    <div class="qr-amount">₹<?php echo htmlspecialchars($price); ?></div>
    <div class="qr-label">Scan this QR with any UPI app to pay</div>
    <div style="background:var(--bg-card2);padding:10px;border-radius:10px;font-size:13px;color:var(--text-dim);word-break:break-all">
      UPI ID: <strong style="color:var(--text)"><?php echo htmlspecialchars($upi); ?></strong>
    </div>
  </div>

  <div style="margin-top:24px">
    <form method="POST">
      <div class="input-group">
        <label>Enter UTR / Transaction ID (12 digits)</label>
        <input type="text" name="utr" placeholder="e.g. 123456789012" required maxlength="30">
      </div>
      <button type="submit" class="btn">✅ Submit Payment Request</button>
    </form>
  </div>

  <div style="margin-top:16px;text-align:center;font-size:13px;color:var(--text-dim)">
    After payment, enter your UTR number above and submit. Admin will verify and approve your request shortly.
  </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer_simple.php'; ?>
