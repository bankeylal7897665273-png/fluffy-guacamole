<?php if(!isset($_SESSION)) session_start(); ?>
<!DOCTYPE html>
<html lang="en" data-theme="<?php echo $_SESSION['theme'] ?? 'dark'; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $pageTitle ?? 'VIP Shop'; ?></title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="loader-overlay" id="pageLoader"><div class="spinner"></div></div>
