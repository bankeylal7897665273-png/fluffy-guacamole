<?php
require_once 'config.php';
if (isset($_SESSION['uid'])) {
    header("Location: dashboard.php");
} else {
    header("Location: login.php");
}
exit;
