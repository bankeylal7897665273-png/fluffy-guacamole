<?php
require_once 'config.php';
require_login();

$msg = '';
$err = '';

// Theme change
if (isset($_GET['theme'])) {
    $allowed = ['dark', 'light', 'colorful'];
    if (in_array($_GET['theme'], $allowed)) {
        $_SESSION['theme'] = $_GET['theme'];
    }
    header("Location: settings.php");
    exit;
}

// Profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        $name = trim($_POST['name']);
        fb_update("/users/" . $_SESSION['uid'], ["name" => $name]);
        $msg = "Profile updated successfully!";
    }

    if (isset($_POST['action']) && $_POST['action'] === 'change_password') {
        $newPassword = $_POST['new_password'];
        if (strlen($newPassword) < 6) {
            $err = "Password must be at least 6 characters.";
        } else {
            $url = "https://identitytoolkit.googleapis.com/v1/accounts:update?key=" . FIREBASE_API_KEY;
            $data = ["idToken" => $_SESSION['idToken'], "password" => $newPassword, "returnSecureToken" => true];
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            $res = json_decode(curl_exec($ch), true);
            curl_close($ch);
            if (isset($res['idToken'])) {
                $_SESSION['idToken'] = $res['idToken'];
                $msg = "Password changed successfully!";
            } else {
                $err = "Failed to change password: " . ($res['error']['message'] ?? 'Unknown error');
            }
        }
    }
}

$profile = fb_get("/users/" . $_SESSION['uid']);

// Stats
$allRequests = fb_get("/requests");
$total = 0; $pending = 0; $success = 0; $rejected = 0;
if ($allRequests && is_array($allRequests)) {
    foreach ($allRequests as $r) {
        if (($r['uid'] ?? '') === $_SESSION['uid']) {
            $total++;
            if (($r['status'] ?? '') === 'pending') $pending++;
            if (($r['status'] ?? '') === 'success') $success++;
            if (($r['status'] ?? '') === 'rejected') $rejected++;
        }
    }
}

$pageTitle = "Settings - VIP Shop";
$active = 'settings';
include 'includes/header.php';
?>
<div class="topbar">
  <h1>⚙️ Settings</h1>
  <div style="width:40px"></div>
</div>

<div class="container">
  <?php if ($msg): ?><div class="success-msg fade-scroll"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
  <?php if ($err): ?><div class="error-msg fade-scroll"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

  <!-- Theme -->
  <div class="settings-section fade-scroll">
    <h3>Appearance</h3>
    <div class="theme-options">
      <a href="?theme=dark" class="theme-opt <?php echo ($_SESSION['theme']??'dark')=='dark'?'active':''; ?>">🌙 Dark</a>
      <a href="?theme=light" class="theme-opt <?php echo ($_SESSION['theme']??'')=='light'?'active':''; ?>">☀️ Light</a>
      <a href="?theme=colorful" class="theme-opt <?php echo ($_SESSION['theme']??'')=='colorful'?'active':''; ?>">🎨 Colorful</a>
    </div>
  </div>

  <!-- Stats -->
  <div class="settings-section fade-scroll">
    <h3>My Stats</h3>
    <div class="stat-row"><span>Total Projects Bought</span><span class="val"><?php echo $success; ?></span></div>
    <div class="stat-row"><span>Pending Requests</span><span class="val"><?php echo $pending; ?></span></div>
    <div class="stat-row"><span>Rejected Requests</span><span class="val"><?php echo $rejected; ?></span></div>
    <div class="stat-row"><span>Total Requests</span><span class="val"><?php echo $total; ?></span></div>
  </div>

  <!-- Profile -->
  <div class="settings-section fade-scroll">
    <h3>Profile</h3>
    <form method="POST">
      <input type="hidden" name="action" value="update_profile">
      <div class="input-group">
        <label>Display Name</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($profile['name'] ?? ''); ?>" required>
      </div>
      <div class="input-group">
        <label>Email</label>
        <input type="email" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" disabled style="opacity:.6">
      </div>
      <button type="submit" class="btn">Update Profile</button>
    </form>
  </div>

  <!-- Password -->
  <div class="settings-section fade-scroll">
    <h3>Change Password</h3>
    <form method="POST">
      <input type="hidden" name="action" value="change_password">
      <div class="input-group">
        <label>New Password</label>
        <input type="password" name="new_password" placeholder="At least 6 characters" required minlength="6">
      </div>
      <button type="submit" class="btn">Change Password</button>
    </form>
  </div>

  <!-- Logout -->
  <a href="logout.php" class="btn btn-danger fade-scroll">🚪 Logout</a>
</div>

<?php include 'includes/footer.php'; ?>
