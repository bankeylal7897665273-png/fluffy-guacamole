<?php
require_once 'config.php';
if (isset($_SESSION['uid'])) { header("Location: dashboard.php"); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $res = fb_signin($email, $password);

    if (isset($res['idToken'])) {
        $_SESSION['uid'] = $res['localId'];
        $_SESSION['email'] = $res['email'];
        $_SESSION['idToken'] = $res['idToken'];
        $_SESSION['theme'] = $_SESSION['theme'] ?? 'dark';

        // Ensure user profile exists in DB
        $profile = fb_get("/users/" . $res['localId']);
        if (!$profile) {
            fb_set("/users/" . $res['localId'], [
                "email" => $res['email'],
                "name" => explode('@', $res['email'])[0],
                "created_at" => date('Y-m-d H:i:s')
            ]);
        }
        header("Location: dashboard.php");
        exit;
    } else {
        $msg = $res['error']['message'] ?? 'LOGIN_FAILED';
        if (strpos($msg, 'INVALID') !== false || strpos($msg, 'PASSWORD') !== false || strpos($msg, 'EMAIL_NOT_FOUND') !== false) {
            $error = 'Invalid email or password.';
        } else {
            $error = 'Login failed: ' . $msg;
        }
    }
}

$pageTitle = "Login - VIP Shop";
include 'includes/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-logo">⚡ VIP Shop</div>
    <div class="auth-sub">Login to your VIP account</div>

    <?php if ($error): ?>
      <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="input-group">
        <label>Email Address</label>
        <input type="email" name="email" placeholder="you@example.com" required>
      </div>
      <div class="input-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn">Login</button>
    </form>

    <div class="auth-switch">
      Don't have an account? <a href="register.php">Create one</a>
    </div>
  </div>
</div>
<?php include 'includes/footer_simple.php'; ?>
