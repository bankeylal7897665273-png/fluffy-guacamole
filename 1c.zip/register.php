<?php
require_once 'config.php';
if (isset($_SESSION['uid'])) { header("Location: dashboard.php"); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];

    if ($password !== $repassword) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $res = fb_signup($email, $password);
        if (isset($res['idToken'])) {
            $_SESSION['uid'] = $res['localId'];
            $_SESSION['email'] = $res['email'];
            $_SESSION['idToken'] = $res['idToken'];
            $_SESSION['theme'] = 'dark';

            fb_set("/users/" . $res['localId'], [
                "email" => $res['email'],
                "name" => explode('@', $res['email'])[0],
                "created_at" => date('Y-m-d H:i:s')
            ]);

            header("Location: dashboard.php");
            exit;
        } else {
            $msg = $res['error']['message'] ?? 'SIGNUP_FAILED';
            if (strpos($msg, 'EMAIL_EXISTS') !== false) {
                $error = "An account with this email already exists.";
            } elseif (strpos($msg, 'WEAK_PASSWORD') !== false) {
                $error = "Password is too weak (min 6 characters).";
            } elseif (strpos($msg, 'INVALID_EMAIL') !== false) {
                $error = "Invalid email address.";
            } else {
                $error = "Signup failed: " . $msg;
            }
        }
    }
}

$pageTitle = "Create Account - VIP Shop";
include 'includes/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-logo">⚡ VIP Shop</div>
    <div class="auth-sub">Create your VIP account</div>

    <?php if ($error): ?>
      <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="input-group">
        <label>Email Address</label>
        <input type="email" name="email" placeholder="you@example.com" required>
      </div>
      <div class="input-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="At least 6 characters" required>
      </div>
      <div class="input-group">
        <label>Re-enter Password</label>
        <input type="password" name="repassword" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn">Create Account</button>
    </form>

    <div class="auth-switch">
      Already have an account? <a href="login.php">Login</a>
    </div>
  </div>
</div>
<?php include 'includes/footer_simple.php'; ?>
