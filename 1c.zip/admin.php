<?php
require_once 'config.php';
require_admin();

$msg = ''; $err = '';

// ===== Handle Actions =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Add Project
    if ($action === 'add_project') {
        $name = trim($_POST['name']);
        $price = floatval($_POST['price']);
        $img = trim($_POST['img']);
        $link = trim($_POST['link']);
        $description = trim($_POST['description']);

        if ($name && $price >= 0 && $img && $link) {
            $res = fb_push("/projects", [
                "name" => $name,
                "price" => $price,
                "img" => $img,
                "link" => $link,
                "description" => $description,
                "created_at" => date('Y-m-d H:i:s')
            ]);
            $msg = "Project added successfully!";
        } else {
            $err = "Please fill all required fields.";
        }
    }

    // Edit Project
    if ($action === 'edit_project') {
        $pid = $_POST['project_id'];
        fb_update("/projects/" . $pid, [
            "name" => trim($_POST['name']),
            "price" => floatval($_POST['price']),
            "img" => trim($_POST['img']),
            "link" => trim($_POST['link']),
            "description" => trim($_POST['description'])
        ]);
        $msg = "Project updated successfully!";
    }

    // Delete Project
    if ($action === 'delete_project') {
        fb_delete("/projects/" . $_POST['project_id']);
        $msg = "Project deleted.";
    }

    // Update UPI
    if ($action === 'update_upi') {
        fb_set("/settings", ["upi_id" => trim($_POST['upi_id'])]);
        $msg = "UPI ID updated successfully!";
    }

    // Approve / Reject Request
    if ($action === 'process_request') {
        $rid = $_POST['request_id'];
        $status = $_POST['status']; // success or rejected
        $request = fb_get("/requests/" . $rid);

        fb_update("/requests/" . $rid, ["status" => $status]);

        if ($status === 'success' && $request) {
            // Add to purchases
            fb_set("/purchases/" . $request['uid'] . "/" . $request['project_id'], [
                "purchased_at" => date('Y-m-d H:i:s'),
                "amount" => $request['amount']
            ]);
        }
        $msg = "Request marked as " . $status . ".";
    }
}

// ===== Fetch Data =====
$projects = fb_get("/projects") ?: [];
$requests = fb_get("/requests") ?: [];
$settings = fb_get("/settings") ?: [];
$users = fb_get("/users") ?: [];

// Sort requests newest first, separate pending
$pendingRequests = [];
$processedRequests = [];
if (is_array($requests)) {
    foreach ($requests as $rid => $r) {
        $r['_id'] = $rid;
        if (($r['status'] ?? 'pending') === 'pending') {
            $pendingRequests[] = $r;
        } else {
            $processedRequests[] = $r;
        }
    }
}
usort($pendingRequests, fn($a,$b) => strtotime($b['created_at']??'0') - strtotime($a['created_at']??'0'));
usort($processedRequests, fn($a,$b) => strtotime($b['created_at']??'0') - strtotime($a['created_at']??'0'));

// Stats
$totalSold = 0;
$totalRevenue = 0;
if (is_array($requests)) {
    foreach ($requests as $r) {
        if (($r['status'] ?? '') === 'success') {
            $totalSold++;
            $totalRevenue += floatval($r['amount'] ?? 0);
        }
    }
}

$pageTitle = "Admin Panel - VIP Shop";
$active = 'admin';
include 'includes/header.php';

// current site base url for "copy link"
$base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
?>
<div class="topbar">
  <h1>🛠️ Admin Panel</h1>
  <div style="width:40px"></div>
</div>

<div class="container">
  <?php if ($msg): ?><div class="success-msg fade-scroll"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
  <?php if ($err): ?><div class="error-msg fade-scroll"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

  <!-- Stats overview -->
  <div class="settings-section fade-scroll">
    <h3>Overview</h3>
    <div class="stat-row"><span>Total Projects</span><span class="val"><?php echo is_array($projects)?count($projects):0; ?></span></div>
    <div class="stat-row"><span>Total Sold</span><span class="val"><?php echo $totalSold; ?></span></div>
    <div class="stat-row"><span>Total Revenue</span><span class="val">₹<?php echo number_format($totalRevenue,2); ?></span></div>
    <div class="stat-row"><span>Pending Requests</span><span class="val"><?php echo count($pendingRequests); ?></span></div>
    <div class="stat-row"><span>Total Users</span><span class="val"><?php echo is_array($users)?count($users):0; ?></span></div>
  </div>

  <!-- Tabs -->
  <div class="admin-tabs">
    <div class="admin-tab active" data-tab="projects">📦 Projects</div>
    <div class="admin-tab" data-tab="requests">📨 Requests <?php if(count($pendingRequests)>0): ?>(<?php echo count($pendingRequests); ?>)<?php endif; ?></div>
    <div class="admin-tab" data-tab="payment">💳 Payment</div>
  </div>

  <!-- TAB: Projects -->
  <div class="tab-content" id="tab-projects">
    <!-- Add Project Form -->
    <div class="settings-section fade-scroll">
      <h3>➕ Add New Project</h3>
      <form method="POST">
        <input type="hidden" name="action" value="add_project">
        <div class="input-group">
          <label>Project Name *</label>
          <input type="text" name="name" placeholder="e.g. Premium Course Bundle" required>
        </div>
        <div class="input-group">
          <label>Price (₹) *</label>
          <input type="number" name="price" step="0.01" placeholder="999" required>
        </div>
        <div class="input-group">
          <label>Image URL *</label>
          <input type="url" name="img" placeholder="https://example.com/image.jpg" required>
        </div>
        <div class="input-group">
          <label>Access Link * (opens after purchase approval)</label>
          <input type="url" name="link" placeholder="https://example.com/private-content" required>
        </div>
        <div class="input-group">
          <label>Description</label>
          <textarea name="description" placeholder="Project details, what's included..."></textarea>
        </div>
        <button type="submit" class="btn">Add Project</button>
      </form>
    </div>

    <!-- Project List -->
    <div class="section-title">Manage Projects</div>
    <?php if (!is_array($projects) || empty($projects)): ?>
      <div class="empty-state"><p>No projects added yet.</p></div>
    <?php else: ?>
      <?php foreach ($projects as $pid => $p): if(!$p) continue; ?>
        <?php $projectLink = $base . "/project.php?id=" . $pid; ?>
        <div class="admin-list-item fade-scroll">
          <div class="flex-between">
            <div style="display:flex;gap:10px;align-items:center;flex:1;min-width:0">
              <img src="<?php echo htmlspecialchars($p['img']); ?>" style="width:48px;height:48px;border-radius:10px;object-fit:cover;background:var(--bg-card2)" onerror="this.src='https://via.placeholder.com/48'">
              <div style="min-width:0">
                <div style="font-weight:700;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars($p['name']); ?></div>
                <div style="font-size:13px;color:var(--accent2);font-weight:700">₹<?php echo htmlspecialchars($p['price']); ?></div>
              </div>
            </div>
            <div class="menu-wrap">
              <div class="icon-btn" data-dropdown-toggle>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>
              </div>
              <div class="dropdown">
                <div class="dropdown-item" onclick="copyToClipboard('<?php echo $projectLink; ?>')">🔗 Copy Link</div>
                <div class="dropdown-item" onclick="openEdit('<?php echo $pid; ?>')">✏️ Edit</div>
                <div class="dropdown-item" style="color:var(--danger)" onclick="confirmDelete('<?php echo $pid; ?>')">🗑️ Delete</div>
              </div>
            </div>
          </div>

          <!-- Edit form (hidden) -->
          <form method="POST" id="edit-<?php echo $pid; ?>" style="display:none;margin-top:14px;padding-top:14px;border-top:1px solid var(--border)">
            <input type="hidden" name="action" value="edit_project">
            <input type="hidden" name="project_id" value="<?php echo $pid; ?>">
            <div class="input-group"><label>Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($p['name']); ?>" required></div>
            <div class="input-group"><label>Price</label><input type="number" name="price" step="0.01" value="<?php echo htmlspecialchars($p['price']); ?>" required></div>
            <div class="input-group"><label>Image URL</label><input type="url" name="img" value="<?php echo htmlspecialchars($p['img']); ?>" required></div>
            <div class="input-group"><label>Access Link</label><input type="url" name="link" value="<?php echo htmlspecialchars($p['link']); ?>" required></div>
            <div class="input-group"><label>Description</label><textarea name="description"><?php echo htmlspecialchars($p['description'] ?? ''); ?></textarea></div>
            <button type="submit" class="btn btn-sm">Save Changes</button>
          </form>

          <!-- Delete form (hidden) -->
          <form method="POST" id="del-<?php echo $pid; ?>" style="display:none">
            <input type="hidden" name="action" value="delete_project">
            <input type="hidden" name="project_id" value="<?php echo $pid; ?>">
          </form>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- TAB: Requests -->
  <div class="tab-content" id="tab-requests" style="display:none">
    <div class="section-title">⏳ Pending Requests</div>
    <?php if (empty($pendingRequests)): ?>
      <div class="empty-state"><p>No pending requests.</p></div>
    <?php else: ?>
      <?php foreach ($pendingRequests as $r): ?>
        <div class="admin-list-item fade-scroll">
          <div style="font-weight:700;font-size:14px;margin-bottom:4px"><?php echo htmlspecialchars($r['project_name'] ?? ''); ?></div>
          <div style="font-size:13px;color:var(--text-dim);margin-bottom:2px">👤 <?php echo htmlspecialchars($r['email'] ?? ''); ?></div>
          <div style="font-size:13px;color:var(--text-dim);margin-bottom:2px">💰 ₹<?php echo htmlspecialchars($r['amount'] ?? '0'); ?></div>
          <div style="font-size:13px;color:var(--text-dim);margin-bottom:10px">🧾 UTR: <strong style="color:var(--text)"><?php echo htmlspecialchars($r['utr'] ?? ''); ?></strong></div>
          <div style="display:flex;gap:8px">
            <form method="POST" style="flex:1">
              <input type="hidden" name="action" value="process_request">
              <input type="hidden" name="request_id" value="<?php echo $r['_id']; ?>">
              <input type="hidden" name="status" value="success">
              <button type="submit" class="btn btn-sm" style="width:100%;background:linear-gradient(135deg,var(--success),#00b894)">✅ Approve</button>
            </form>
            <form method="POST" style="flex:1">
              <input type="hidden" name="action" value="process_request">
              <input type="hidden" name="request_id" value="<?php echo $r['_id']; ?>">
              <input type="hidden" name="status" value="rejected">
              <button type="submit" class="btn btn-sm btn-danger" style="width:100%">❌ Reject</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <div class="section-title">📋 Processed Requests</div>
    <?php if (empty($processedRequests)): ?>
      <div class="empty-state"><p>No processed requests yet.</p></div>
    <?php else: ?>
      <?php foreach ($processedRequests as $r): 
        $st = $r['status'] ?? '';
        $bc = $st === 'success' ? 'badge-success' : 'badge-rejected';
        $bt = $st === 'success' ? '✅ Approved' : '❌ Rejected';
      ?>
        <div class="admin-list-item fade-scroll">
          <div class="flex-between">
            <div>
              <div style="font-weight:700;font-size:14px"><?php echo htmlspecialchars($r['project_name'] ?? ''); ?></div>
              <div style="font-size:12px;color:var(--text-dim)"><?php echo htmlspecialchars($r['email'] ?? ''); ?> • ₹<?php echo htmlspecialchars($r['amount'] ?? '0'); ?></div>
            </div>
            <span class="badge <?php echo $bc; ?>"><?php echo $bt; ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- TAB: Payment -->
  <div class="tab-content" id="tab-payment" style="display:none">
    <div class="settings-section fade-scroll">
      <h3>💳 UPI Payment Settings</h3>
      <form method="POST">
        <input type="hidden" name="action" value="update_upi">
        <div class="input-group">
          <label>UPI ID</label>
          <input type="text" name="upi_id" value="<?php echo htmlspecialchars($settings['upi_id'] ?? ''); ?>" placeholder="yourname@upi" required>
        </div>
        <button type="submit" class="btn">Update UPI ID</button>
      </form>
      <p style="font-size:12px;color:var(--text-dim);margin-top:12px">
        This UPI ID will be used to generate QR codes for all purchases. Make sure it's correct and active.
      </p>
    </div>
  </div>
</div>

<script>
// Tab switching
document.querySelectorAll('.admin-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
    tab.classList.add('active');
    document.getElementById('tab-' + tab.dataset.tab).style.display = 'block';
  });
});

function openEdit(pid) {
  const form = document.getElementById('edit-' + pid);
  form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

function confirmDelete(pid) {
  if (confirm('Delete this project? This cannot be undone.')) {
    document.getElementById('del-' + pid).submit();
  }
}
</script>

<?php include 'includes/footer.php'; ?>
