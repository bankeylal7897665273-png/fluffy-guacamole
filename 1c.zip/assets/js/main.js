// Hide page loader smoothly
window.addEventListener('load', () => {
  const loader = document.getElementById('pageLoader');
  if (loader) setTimeout(() => loader.classList.add('hide'), 300);
});

// Toast helper
function showToast(msg, duration = 2500) {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), duration);
}

// Generic dropdown toggle (3-dot menus)
document.addEventListener('click', (e) => {
  const trigger = e.target.closest('[data-dropdown-toggle]');
  document.querySelectorAll('.dropdown.show').forEach(dd => {
    if (!trigger || dd !== trigger.nextElementSibling) dd.classList.remove('show');
  });
  if (trigger) {
    const dd = trigger.nextElementSibling;
    dd.classList.toggle('show');
  }
});

// Copy to clipboard
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => showToast('Link copied!'));
}

// Button loading state on form submit
document.addEventListener('submit', (e) => {
  const btn = e.target.querySelector('button[type="submit"]');
  if (btn && !btn.dataset.noLoading) {
    btn.dataset.original = btn.innerHTML;
    btn.innerHTML = '<span class="spinner small"></span> Please wait...';
    btn.disabled = true;
  }
});

// Smooth fade-in for elements on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.fade-scroll').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = 'all .6s ease';
  observer.observe(el);
});
