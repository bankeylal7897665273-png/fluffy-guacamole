<?php
require_once 'config.php';
require_login();

$id = $_GET['id'] ?? '';
if (!$id) { header("Location: dashboard.php"); exit; }

$project = fb_get("/projects/" . $id);
if (!$project) { header("Location: dashboard.php"); exit; }

// Check if user already purchased this project (approved)
$purchases = fb_get("/purchases/" . $_SESSION['uid']);
$owned = false;
if ($purchases && is_array($purchases)) {
    foreach ($purchases as $pid => $val) {
        if ($pid === $id) { $owned = true; break; }
    }
}

// Check pending request for this project
$requests = fb_get("/requests");
$pendingStatus = null;
if ($requests && is_array($requests)) {
    foreach ($requests as $rid => $r) {
        if (($r['uid'] ?? '') === $_SESSION['uid'] && ($r['project_id'] ?? '') === $id) {
            $pendingStatus = $r['status'] ?? 'pending';
        }
    }
}

$pageTitle = htmlspecialchars($project['name'] ?? 'Project') . " - VIP Shop";
$active = 'dashboard';
include 'includes/header.php';
?>
<div class="topbar">
  <a href="dashboard.php" class="icon-btn">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
  </a>
  <h1>Project Details</h1>
  <div style="width:40px"></div>
</div>

<div class="container">
  <img class="hero-img fade-scroll" 
       src="<?php echo htmlspecialchars($project['img'] ?? 'https://via.placeholder.com/600x400'); ?>" 
       alt="<?php echo htmlspecialchars($project['name'] ?? ''); ?>"
       onerror="this.src='https://via.placeholder.com/600x400?text=Image'">

  <div class="project-title fade-scroll"><?php echo htmlspecialchars($project['name'] ?? 'Untitled'); ?></div>
  <div class="project-price fade-scroll">₹<?php echo htmlspecialchars($project['price'] ?? '0'); ?></div>
  <div class="project-desc fade-scroll"><?php echo nl2br(htmlspecialchars($project['description'] ?? 'No description available for this project.')); ?></div>

  <?php if ($owned): ?>
    <a href="<?php echo htmlspecialchars($project['link'] ?? '#'); ?>" target="_blank" class="btn fade-scroll" style="margin-bottom:14px">
      🔓 Open Project
    </a>
    <div class="success-msg">✅ You own this project. Click above to access it.</div>
  <?php elseif ($pendingStatus === 'pending'): ?>
    <div class="error-msg" style="background:rgba(255,165,2,.12);color:var(--warn)">
      ⏳ Your payment is under review. Check History for status.
    </div>
    <a href="history.php" class="btn btn-outline fade-scroll">View Status</a>
  <?php else: ?>
    <a href="buy.php?id=<?php echo urlencode($id); ?>" class="btn fade-scroll">
      💎 Buy Now
    </a>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
