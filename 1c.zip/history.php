<?php
require_once 'config.php';
require_login();

$allRequests = fb_get("/requests");
$myRequests = [];
if ($allRequests && is_array($allRequests)) {
    foreach ($allRequests as $rid => $r) {
        if (($r['uid'] ?? '') === $_SESSION['uid']) {
            $r['_id'] = $rid;
            $myRequests[] = $r;
        }
    }
}
// Sort newest first
usort($myRequests, function($a, $b) {
    return strtotime($b['created_at'] ?? '0') - strtotime($a['created_at'] ?? '0');
});

$pageTitle = "History - VIP Shop";
$active = 'history';
include 'includes/header.php';
?>
<div class="topbar">
  <h1>📜 My History</h1>
  <div style="width:40px"></div>
</div>

<div class="container">
  <?php if (empty($myRequests)): ?>
    <div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
      <p>No purchase history yet.</p>
      <p style="font-size:13px;margin-top:6px">Your requests will appear here.</p>
    </div>
  <?php else: ?>
    <?php foreach ($myRequests as $r): 
        $status = $r['status'] ?? 'pending';
        $project = fb_get("/projects/" . ($r['project_id'] ?? ''));
        $badgeClass = $status === 'success' ? 'badge-success' : ($status === 'rejected' ? 'badge-rejected' : 'badge-pending');
        $badgeText = $status === 'success' ? '✅ Success' : ($status === 'rejected' ? '❌ Rejected' : '⏳ Pending');
    ?>
    <div class="history-item fade-scroll">
      <img src="<?php echo htmlspecialchars($project['img'] ?? 'https://via.placeholder.com/60'); ?>" 
           onerror="this.src='https://via.placeholder.com/60'">
      <div class="history-info">
        <div class="name"><?php echo htmlspecialchars($r['project_name'] ?? 'Project'); ?></div>
        <div class="meta">₹<?php echo htmlspecialchars($r['amount'] ?? '0'); ?> • UTR: <?php echo htmlspecialchars($r['utr'] ?? '-'); ?></div>
        <div class="meta"><?php echo htmlspecialchars($r['created_at'] ?? ''); ?></div>
        <div style="margin-top:6px;display:flex;align-items:center;gap:8px">
          <span class="badge <?php echo $badgeClass; ?>">
            <?php if($status === 'pending'): ?><span class="badge-dot"></span><?php endif; ?>
            <?php echo $badgeText; ?>
          </span>
          <?php if ($status === 'rejected'): ?>
            <a href="buy.php?id=<?php echo urlencode($r['project_id'] ?? ''); ?>" class="btn btn-sm btn-danger">Help / Retry</a>
          <?php elseif ($status === 'success'): ?>
            <a href="project.php?id=<?php echo urlencode($r['project_id'] ?? ''); ?>" class="btn btn-sm">Open</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
